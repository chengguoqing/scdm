var km = new Vue({
	el: '#app_slider',
	data: {

	},
	methods: {

	},
	mounted() {
	}
})
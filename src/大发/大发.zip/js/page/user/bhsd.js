//偏好设定
var km = new Vue({
	el: '#bhsd',
	data: {

	},
	methods: {

	},
	mounted() {
	}
})
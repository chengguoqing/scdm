//banner
Vue.component('banner', {
    props: {
        banner: ""
    },
    template: `
 
    `,
    data: function data() {
        return {

        };
    },
    mounted() {

      
    },
    methods: {

    }

});
